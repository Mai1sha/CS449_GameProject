namespace SOSGame.Models
{
    public enum Player
    {
        Blue,
        Red
    }
}
