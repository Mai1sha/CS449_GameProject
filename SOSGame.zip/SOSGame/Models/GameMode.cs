namespace SOSGame.Models
{
    public enum GameMode
    {
        Simple,
        General
    }
}
