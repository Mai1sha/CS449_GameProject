namespace SOSGame.Models
{
    public enum CellValue
    {
        Empty,
        S,
        O
    }
}
