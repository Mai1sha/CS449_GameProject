# SOS Game - Complete Architecture & Workflow Guide

## Table of Contents
1. [Overall Architecture](#overall-architecture)
2. [Code Components](#code-components)
3. [Data Models](#data-models)
4. [User Interface Flow](#user-interface-flow)
5. [Complete Gameplay Workflow](#complete-gameplay-workflow)

---

## Overall Architecture

### Application Flow Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                      APPLICATION FLOW                           │
└─────────────────────────────────────────────────────────────────┘

1. Program.cs (Entry Point)
   ↓
2. StartForm (Home Screen)
   ├─ User enters board size
   ├─ User selects game mode (Simple/General)
   ├─ User clicks "Start Game"
   ↓
3. GameForm (Main Game Board)
   ├─ Displays game board
   ├─ Manages turn-based gameplay
   ├─ Handles player moves
   ├─ Uses GameState & Board models
   ↓
4. Models (Game Logic Layer)
   ├─ GameState: Controls game flow
   ├─ Board: Manages board state
   ├─ Player/CellValue/GameMode: Enums
   ↓
5. Game Loop Until "New Game" or Exit
```

### Design Pattern: Model-View-Controller (MVC)

The application follows the **MVC pattern** adapted for Windows Forms:

```
┌─────────────────────────────────────────────────────────────────┐
│ VIEW LAYER (User Interface)                                     │
│ ├─ StartForm.cs - Game setup screen                            │
│ ├─ GameForm.cs - Game board display                            │
│ └─ Designer files - UI controls and layout                     │
└────────┬──────────────────────────────────────────────────────┘
         │ Calls methods / sends user input
         ↓
┌─────────────────────────────────────────────────────────────────┐
│ CONTROLLER LAYER (Business Logic)                               │
│ ├─ GameState.cs - Game flow orchestration                       │
│ ├─ Game rules enforcement                                       │
│ └─ Turn management                                              │
└────────┬──────────────────────────────────────────────────────┘
         │ Updates / Queries
         ↓
┌─────────────────────────────────────────────────────────────────┐
│ MODEL LAYER (Data Storage)                                      │
│ ├─ Board.cs - Game board state                                 │
│ ├─ Enums - CellValue, Player, GameMode                         │
│ └─ Game data representation                                     │
└─────────────────────────────────────────────────────────────────┘
```

---

## Code Components

### 1. Program.cs - Application Entry Point

**Purpose:** Initialize and launch the application

```csharp
using SOSGame_2;

static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new StartForm());
    }
}
```

**Explanation:**
- `[STAThread]` - Required for Windows Forms (Single Threaded Apartment)
- `ApplicationConfiguration.Initialize()` - Sets up Windows Forms infrastructure
- `Application.Run(new StartForm())` - **Launches the StartForm as the first screen**
- This is the **only entry point** into your application

---

### 2. StartForm.cs - Game Setup Screen

**Purpose:** Allow user to configure game parameters

```
┌──────────────────────────────────┐
│      SOS Game Setup Screen       │
├──────────────────────────────────┤
│ Board Size:     [_______]  [✓]   │
│ Game Mode:   ◉ Simple            │
│              ◉ General           │
│                                  │
│        [ Start Game ]            │
└──────────────────────────────────┘
```

**User Interactions:**
1. User enters board size (3-8 typically)
2. User selects game mode (Simple or General)
3. User clicks "Start Game" button

**Key Method: `startGameButton_Click()`**

```csharp
private void startGameButton_Click(object sender, EventArgs e)
{
    // Validate and get board size
    if (!TryGetBoardSize(out int boardSize))
    {
        MessageBox.Show("Please enter a valid board size (must be >= 3)", 
                       "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        return;
    }

    // Get selected game mode
    GameMode gameMode = GetSelectedGameMode();

    // Start the game
    StartGame(boardSize, gameMode);
}

private void StartGame(int boardSize, GameMode gameMode)
{
    _gameForm = new GameForm(boardSize, gameMode);
    _gameForm.FormClosed += GameForm_FormClosed;
    _gameForm.Show();
    this.Hide();
}
```

**Data Flow:**
- Validates input (size must be ≥ 3, no letters)
- Creates **GameForm** with the selected parameters
- Passes data through constructor
- Hides StartForm
- Shows GameForm

---

### 3. GameForm.cs - Main Game Interface

**Purpose:** Display and manage the game board UI

```
┌──────────────────────────────────────────────────────┐
│                  GAME BOARD UI                       │
├──────────────────────────────────────────────────────┤
│  [Game Grid Display - 8×8 shown]                     │
│  ┌─┬─┬─┬─┬─┬─┬─┬─┐                                   │
│  │ │S│ │O│ │ │ │ │                                   │
│  ├─┼─┼─┼─┼─┼─┼─┼─┤                                   │
│  │ │ │O│ │ │ │S│ │                                   │
│  └─┴─┴─┴─┴─┴─┴─┴─┘                                   │
│                                                       │
│  Current Turn: Blue (or Red)                         │
│  [Place S (Blue)] [Place O (Red's turn)]             │
│  [New Game]                                          │
└──────────────────────────────────────────────────────┘
```

**Key Components:**

```csharp
public partial class GameForm : Form
{
    private GameState _gameState;
    private Button[,] _gridButtons;
    private const int CellSize = 50;
    private const int CellMargin = 10;

    public GameForm(int boardSize, GameMode gameMode)
    {
        InitializeComponent();
        _gameState = new GameState(boardSize, gameMode);
        _gridButtons = new Button[boardSize, boardSize];

        WireUpEventHandlers();
        InitializeBoard();
        UpdateUI();
    }
}
```

**Key Methods:**

| Method | Purpose |
|--------|---------|
| `InitializeBoard()` | Creates visual grid on screen |
| `CellButton_Click()` | Handles cell selection |
| `btnPlaceS_Click()` | Handles S placement |
| `btnPlaceO_Click()` | Handles O placement |
| `PlaceMove()` | Validates and executes move |
| `UpdateUI()` | Updates turn indicator and button states |
| `btnNewGame_Click()` | Resets game |

---

## Data Models

### Enumerations - Simple Data Types

#### Player.cs
```csharp
public enum Player
{
    Blue,  // Places 'S'
    Red    // Places 'O'
}
```

#### CellValue.cs
```csharp
public enum CellValue
{
    Empty,
    S,
    O
}
```

#### GameMode.cs
```csharp
public enum GameMode
{
    Simple,   // First to create SOS wins
    General   // All SOS sequences count
}
```

**Purpose:** These are **data containers** - just values, no logic

---

### Board.cs - Board State Management

**Responsibility:** Store and manage the game board state

```csharp
public class Board
{
    private readonly int _size;
    private readonly CellValue[,] _cells;

    public int Size => _size;

    public Board(int size)
    {
        if (size < 3)
            throw new ArgumentException("Board size must be at least 3", nameof(size));

        _size = size;
        _cells = new CellValue[size, size];
        InitializeBoard();
    }

    private void InitializeBoard()
    {
        for (int row = 0; row < _size; row++)
        {
            for (int col = 0; col < _size; col++)
            {
                _cells[row, col] = CellValue.Empty;
            }
        }
    }

    public CellValue GetCell(int row, int col)
    {
        ValidateCoordinates(row, col);
        return _cells[row, col];
    }

    public bool PlaceMove(int row, int col, CellValue value)
    {
        ValidateCoordinates(row, col);

        if (value == CellValue.Empty)
            throw new ArgumentException("Cannot place empty cell", nameof(value));

        if (_cells[row, col] != CellValue.Empty)
            return false; // Cell already occupied

        _cells[row, col] = value;
        return true;
    }

    public bool IsCellEmpty(int row, int col)
    {
        ValidateCoordinates(row, col);
        return _cells[row, col] == CellValue.Empty;
    }

    public bool IsFull()
    {
        for (int row = 0; row < _size; row++)
        {
            for (int col = 0; col < _size; col++)
            {
                if (_cells[row, col] == CellValue.Empty)
                    return false;
            }
        }
        return true;
    }

    public void Reset()
    {
        InitializeBoard();
    }

    private void ValidateCoordinates(int row, int col)
    {
        if (row < 0 || row >= _size || col < 0 || col >= _size)
            throw new ArgumentOutOfRangeException($"Coordinates ({row}, {col}) out of bounds");
    }
}
```

**Key Responsibilities:**
- ✅ Stores the game board as a 2D array `CellValue[,]`
- ✅ Validates cell access (must be within bounds)
- ✅ Prevents duplicate moves (cell must be empty)
- ✅ Tracks board state (full or not)
- ✅ Resets board for new games

**Usage Example:**
```csharp
Board board = new Board(8);              // Create 8×8 board
bool success = board.PlaceMove(0, 0, CellValue.S);  // Place 'S'
CellValue cell = board.GetCell(0, 0);    // Retrieve it
// cell = CellValue.S
```

---

### GameState.cs - Game Logic & Flow Control

**Responsibility:** Orchestrate gameplay and enforce game rules

```csharp
public class GameState
{
    private readonly Board _board;
    private readonly GameMode _gameMode;
    private Player _currentPlayer;

    public Board Board => _board;
    public GameMode Mode => _gameMode;
    public Player CurrentPlayer => _currentPlayer;

    public GameState(int boardSize, GameMode gameMode = GameMode.Simple)
    {
        _board = new Board(boardSize);
        _gameMode = gameMode;
        _currentPlayer = Player.Blue;
    }

    public bool MakeMove(int row, int col, CellValue cellValue)
    {
        bool moveSuccessful = _board.PlaceMove(row, col, cellValue);

        if (moveSuccessful)
        {
            SwitchPlayer();
        }

        return moveSuccessful;
    }

    private void SwitchPlayer()
    {
        _currentPlayer = _currentPlayer == Player.Blue ? Player.Red : Player.Blue;
    }

    public void Reset()
    {
        _board.Reset();
        _currentPlayer = Player.Blue;
    }
}
```

**Key Responsibilities:**
- ✅ Orchestrates gameplay - decides whose turn it is
- ✅ Validates and executes moves - ensures legal moves only
- ✅ Switches turns - alternates between Blue and Red
- ✅ Manages game state - tracks current player
- ✅ Delegates to Board - for physical board operations

**Usage Example:**
```csharp
GameState game = new GameState(8, GameMode.Simple);

// Blue's first move
bool success = game.MakeMove(3, 3, CellValue.S);  // Blue places S
// Now CurrentPlayer = Red automatically

// Red's move
success = game.MakeMove(4, 4, CellValue.O);  // Red places O
// Now CurrentPlayer = Blue automatically
```

---

## User Interface Flow

### Connection Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                      USER INTERACTION LAYER                      │
│                        (GameForm UI)                             │
│  [Grid Display] [Place S] [Place O] [New Game]                  │
└────────┬──────────────────────────┬─────────────────────────────┘
         │                          │
         │ MakeMove(row,col,value)  │
         ↓                          ↓
┌─────────────────────────────────────────────────────────────────┐
│                    GAME LOGIC LAYER                              │
│                    (GameState Model)                             │
│  - Validates move                                                │
│  - Delegates to Board                                            │
│  - Switches turns                                                │
└────────┬──────────────────────────┬─────────────────────────────┘
         │                          │
         │ PlaceMove(row,col,value) │
         ↓                          ↓
┌─────────────────────────────────────────────────────────────────┐
│                   DATA STORAGE LAYER                             │
│                    (Board Model)                                 │
│  - _grid[,] array                                                │
│  - Stores game state                                             │
│  - Validates cell access                                         │
└─────────────────────────────────────────────────────────────────┘
         │
         │ Returns CellValue
         ↓
┌─────────────────────────────────────────────────────────────────┐
│                  UPDATE UI LAYER                                 │
│  - RefreshBoard()                                                │
│  - UpdateTurnIndicator()                                         │
│  - Display moves to user                                         │
└─────────────────────────────────────────────────────────────────┘
```

---

## Complete Gameplay Workflow

### Step-by-Step Game Initialization (From Board Size Entry to Game Board Display)

#### Step 1: Application Starts (Program.cs)

```csharp
// This runs FIRST when you open the app
static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new StartForm());  // ← Creates StartForm window
    }
}
```

**What Happens:**
- The app launches
- Creates the **StartForm** object
- Shows it on screen
- Waits for user input

#### Step 2: User Enters Board Size and Selects Game Mode

```
Screen shows:
┌─────────────────────────────┐
│  SOS Game Setup             │
├─────────────────────────────┤
│  Board Size: [_____]        │  ← User types "8" here
│  Game Mode:                 │
│  ◉ Simple  ○ General        │  ← User selects "Simple"
│  [ Start ]                  │  ← User clicks here
└─────────────────────────────┘
```

**No code runs yet** - just UI state change.

#### Step 3: User Clicks "Start" Button ⭐ **THIS IS WHERE THE MAGIC HAPPENS**

```csharp
// StartForm.cs
private void btnStart_Click(object sender, EventArgs e)
{
    // Step 3a: Get the board size from the text box
    string boardSizeText = BoardSizeTextBox.Text;
    // boardSizeText = "8"
    
    // Step 3b: Try to convert to integer
    if (!TryGetBoardSize(out int boardSize))
    {
        MessageBox.Show("Please enter a valid board size (must be >= 3)");
        return;  // Stop here if invalid
    }
    // boardSize = 8 (now it's a number, not text)
    
    // Step 3c: Determine which game mode was selected
    GameMode selectedMode = generalGameButton.Checked 
        ? GameMode.General 
        : GameMode.Simple;
    // selectedMode = GameMode.Simple
    
    // Step 3d: CREATE THE GAMEFORM (Most important!)
    GameForm gameForm = new GameForm(boardSize, selectedMode);
    // ↓↓↓ THIS CALLS GameForm's Constructor ↓↓↓
    
    // Step 3e: Show the game form
    gameForm.Show();
    // The GameForm window appears on screen
    
    // Step 3f: Hide the start form
    this.Hide();
    // StartForm disappears
}
```

**At this point:**
- `boardSize = 8`
- `selectedMode = GameMode.Simple`
- A new **GameForm** object is being created with those values

#### Step 4: GameForm Constructor Runs 🔥 **THE REAL ACTION STARTS HERE**

```csharp
// GameForm.cs - Constructor
public GameForm(int boardSize, GameMode gameMode)
{
    // Step 4a: Initialize Windows Forms components
    InitializeComponent();
    // This creates all buttons, labels, etc. from Designer
    
    // Step 4b: CREATE THE GAME STATE ← THIS IS KEY!
    _gameState = new GameState(boardSize, gameMode);
    // boardSize = 8
    // gameMode = GameMode.Simple
    // ↓↓↓ THIS CALLS GameState's Constructor ↓↓↓
    
    // Step 4c: Initialize the board display
    InitializeBoard();
    // ↓↓↓ DRAWS THE GRID ON SCREEN ↓↓↓
    
    // Step 4d: Set initial turn indicator
    UpdateUI();
    // Shows "Blue's Turn" on screen
}
```

#### Step 5: GameState Constructor Creates the Board

```csharp
// GameState.cs - Constructor
public GameState(int boardSize, GameMode gameMode = GameMode.Simple)
{
    // Step 5a: CREATE THE BOARD OBJECT
    _board = new Board(boardSize);
    // boardSize = 8
    // ↓↓↓ THIS CALLS Board's Constructor ↓↓↓
    
    // Step 5b: Store the game mode
    _gameMode = gameMode;
    // _gameMode = GameMode.Simple
    
    // Step 5c: Set first player
    _currentPlayer = Player.Blue;
    // Blue always goes first!
}
```

#### Step 6: Board Constructor Creates the Game Grid

```csharp
// Board.cs - Constructor
public Board(int size)
{
    // Step 6a: Validate size
    if (size < 3)
    {
        throw new ArgumentException("Board size must be at least 3", nameof(size));
    }
    // Validation passed! size = 8 ✓
    
    // Step 6b: Store the size
    _size = size;
    // _size = 8
    
    // Step 6c: CREATE THE ACTUAL GRID (2D array)
    _cells = new CellValue[size, size];
    // Creates an 8×8 array:
    // _cells[0,0] _cells[0,1] ... _cells[0,7]
    // _cells[1,0] _cells[1,1] ... _cells[1,7]
    // ...
    // _cells[7,0] _cells[7,1] ... _cells[7,7]
    
    // Step 6d: Fill all cells with "Empty"
    for (int row = 0; row < size; row++)
    {
        for (int col = 0; col < size; col++)
        {
            _cells[row, col] = CellValue.Empty;
            // Every single cell is set to Empty
        }
    }
    // Now _cells looks like:
    // [ ][ ][ ][ ][ ][ ][ ][ ]
    // [ ][ ][ ][ ][ ][ ][ ][ ]
    // [ ][ ][ ][ ][ ][ ][ ][ ]
    // [ ][ ][ ][ ][ ][ ][ ][ ]
    // [ ][ ][ ][ ][ ][ ][ ][ ]
    // [ ][ ][ ][ ][ ][ ][ ][ ]
    // [ ][ ][ ][ ][ ][ ][ ][ ]
    // [ ][ ][ ][ ][ ][ ][ ][ ]
}
```

#### Step 7: GameForm - InitializeBoard() Draws the Grid

Back in the GameForm constructor, at the `InitializeBoard()` call:

```csharp
// GameForm.cs
private void InitializeBoard()
{
    int boardSize = _gameState.Board.Size;
    int boardWidth = CalculateBoardDimension(boardSize);
    int boardHeight = CalculateBoardDimension(boardSize);

    ResizeForm(boardWidth, boardHeight);
    ConfigureGamePanel(boardWidth, boardHeight);
    PositionControlButtons(boardHeight);
    CreateGridButtons(boardSize);
}

private void CreateGridButtons(int boardSize)
{
    _gridButtons = new Button[boardSize, boardSize];
    
    for (int row = 0; row < boardSize; row++)
    {
        for (int col = 0; col < boardSize; col++)
        {
            CreateCellButton(row, col);
        }
    }
    // After this loop: 8×8 = 64 clickable cells on screen!
}

private void CreateCellButton(int row, int col)
{
    Button button = new Button
    {
        Width = CellSize,
        Height = CellSize,
        Left = CellMargin + col * (CellSize + CellMargin),
        Top = CellMargin + row * (CellSize + CellMargin),
        Font = new Font("Arial", 16, FontStyle.Bold),
        Tag = (row, col)
    };

    button.Click += (s, e) => CellButton_Click(row, col);
    panelGameBoard.Controls.Add(button);
    _gridButtons[row, col] = button;
}
```

**Visual Result on Screen:**
```
┌─────────────────────────────────────────────────────┐
│  SOS Game                  [ ][ ][ ][ ][ ][ ][ ][ ]  │
│  Blue's Turn              [ ][ ][ ][ ][ ][ ][ ][ ]  │
│                            [ ][ ][ ][ ][ ][ ][ ][ ]  │
│  [Place S] [Place O]       [ ][ ][ ][ ][ ][ ][ ][ ]  │
│  [New Game]                [ ][ ][ ][ ][ ][ ][ ][ ]  │
│                            [ ][ ][ ][ ][ ][ ][ ][ ]  │
│                            [ ][ ][ ][ ][ ][ ][ ][ ]  │
│                            [ ][ ][ ][ ][ ][ ][ ][ ]  │
└─────────────────────────────────────────────────────┘
```

Each cell is a clickable Button!

#### Step 8: UpdateUI() Updates Turn Indicator

```csharp
// GameForm.cs
private void UpdateUI()
{
    bool isBluePlayer = _gameState.CurrentPlayer == Player.Blue;
    
    lblTurn.Text = $"Current turn: {_gameState.CurrentPlayer}";
    lblTurn.ForeColor = isBluePlayer ? Color.Blue : Color.Red;
    
    UpdateButtonStates(isBluePlayer);
}

private void UpdateButtonStates(bool isBluePlayer)
{
    if (isBluePlayer)
    {
        btnPlaceS.Enabled = true;
        btnPlaceS.BackColor = Color.LightBlue;
        btnPlaceS.Text = "Place S\n(Blue)";
        
        btnPlaceO.Enabled = false;
        btnPlaceO.BackColor = Color.LightGray;
        btnPlaceO.Text = "Place O\n(Red's turn)";
    }
    else
    {
        btnPlaceS.Enabled = false;
        btnPlaceS.BackColor = Color.LightGray;
        btnPlaceS.Text = "Place S\n(Blue's turn)";
        
        btnPlaceO.Enabled = true;
        btnPlaceO.BackColor = Color.LightCoral;
        btnPlaceO.Text = "Place O\n(Red)";
    }
}
```

**Final Screen:**
```
┌─────────────────────────────────────────────────────┐
│  SOS Game                  [ ][ ][ ][ ][ ][ ][ ][ ]  │
│  Blue's Turn ← Shows whose turn             [ ][ ][ ][ ][ ][ ][ ]  │
│  (text is blue)                  [ ][ ][ ][ ][ ][ ][ ]  │
│                            [ ][ ][ ][ ][ ][ ][ ][ ]  │
│  [Place S]  [Place O]  ← Only "Place S" is lit/blue │
│   (blue)      (gray)     Other is disabled/gray   │
│  [New Game]                [ ][ ][ ][ ][ ][ ][ ][ ]  │
│                            [ ][ ][ ][ ][ ][ ][ ][ ]  │
│                            [ ][ ][ ][ ][ ][ ][ ][ ]  │
└─────────────────────────────────────────────────────┘
```

---

### Constructor Chain Summary 📊

```
User clicks "Start"
    ↓
btnStart_Click() executes
    ↓
new GameForm(8, Simple) ← GameForm Constructor called
    ↓
    ├─ InitializeComponent()
    │   └─ Creates buttons, labels from Designer
    │
    ├─ new GameState(8, Simple) ← GameState Constructor called
    │   │
    │   └─ new Board(8) ← Board Constructor called
    │       │
    │       └─ _cells[,] = new CellValue[8,8]
    │           └─ All 64 cells set to Empty
    │
    ├─ InitializeBoard()
    │   └─ Loop creates 64 Button controls
    │       └─ Each Button positioned and added to screen
    │
    └─ UpdateUI()
        └─ Shows "Blue's Turn"
        └─ Enables [Place S]
        └─ Disables [Place O]
    ↓
GameForm window appears on screen
    ↓
GAME READY FOR PLAY! ✓
```

---

### Memory State at This Point 💾

```csharp
// In GameForm object:
_gameState = GameState object
    ├─ _board = Board object
    │   ├─ _size = 8
    │   └─ _cells[8,8] = 
    │       [Empty][Empty][Empty]...[Empty]  (64 cells)
    │       [Empty][Empty][Empty]...[Empty]
    │       ...
    │
    ├─ _gameMode = GameMode.Simple
    └─ _currentPlayer = Player.Blue

_gridButtons = Button[8,8]  (64 Button controls on screen)
```

---

### Playing a Move - The Complete Cycle

#### User Clicks on a Cell

When user clicks the cell at row 3, column 4:

```csharp
// GameForm.cs
private void CellButton_Click(int row, int col)
{
    ClearPreviousSelection();
    HighlightSelectedCell(row, col);
}

private void HighlightSelectedCell(int row, int col)
{
    _gridButtons[row, col].BackColor = Color.Yellow;
}
```

**Screen shows:**
```
[ ][ ][ ][ ][ ][ ][ ][ ]
[ ][ ][ ][ ][ ][ ][ ][ ]
[ ][ ][ ][ ][ ][ ][ ][ ]
[ ][ ][ ][🟨][ ][ ][ ][ ]  ← Yellow cell at row 3, col 4
[ ][ ][ ][ ][ ][ ][ ][ ]
[ ][ ][ ][ ][ ][ ][ ][ ]
[ ][ ][ ][ ][ ][ ][ ][ ]
[ ][ ][ ][ ][ ][ ][ ][ ]
```

#### User Clicks "Place S" Button

```csharp
// GameForm.cs
private void btnPlaceS_Click(object? sender, EventArgs e)
{
    PlaceMove('S');
}

private void PlaceMove(char value)
{
    // Step 1: Find selected cell
    (int row, int col)? selectedCell = FindSelectedCell();

    if (!selectedCell.HasValue)
    {
        ShowMessage("Please select a cell first!", "No Cell Selected");
        return;
    }

    TryPlaceMoveOnCell(selectedCell.Value.row, selectedCell.Value.col, value);
}

private void TryPlaceMoveOnCell(int row, int col, char value)
{
    // Step 2: Convert char to CellValue
    CellValue cellValue = value == 'S' ? CellValue.S : CellValue.O;
    
    // Step 3: Call GameState to make the move
    bool moveSuccessful = _gameState.MakeMove(row, col, cellValue);

    if (moveSuccessful)
    {
        // Step 4a: Update the cell display
        UpdateCellDisplay(row, col, value);
        
        // Step 4b: UPDATE TURN INDICATOR
        UpdateUI();
        // Now shows "Red's Turn"
        // Now "Place S" is disabled (gray)
        // Now "Place O" is enabled (red)
    }
    else
    {
        ShowMessage("Cell already occupied!", "Invalid Move");
    }
}

private void UpdateCellDisplay(int row, int col, char value)
{
    _gridButtons[row, col].Text = value.ToString();
    _gridButtons[row, col].BackColor = SystemColors.Control;
}
```

#### GameState Processes the Move

```csharp
// GameState.cs
public bool MakeMove(int row, int col, CellValue cellValue)
{
    // Step 1: Delegate to Board
    bool moveSuccessful = _board.PlaceMove(row, col, cellValue);

    // Step 2: If successful, switch turns
    if (moveSuccessful)
    {
        SwitchPlayer();
    }

    return moveSuccessful;
}

private void SwitchPlayer()
{
    _currentPlayer = _currentPlayer == Player.Blue ? Player.Red : Player.Blue;
}
```

#### Board Executes the Move

```csharp
// Board.cs
public bool PlaceMove(int row, int col, CellValue value)
{
    ValidateCoordinates(row, col);

    if (value == CellValue.Empty)
        throw new ArgumentException("Cannot place empty cell", nameof(value));

    // Check if cell is occupied
    if (_cells[row, col] != CellValue.Empty)
        return false; // Cell already occupied, move failed

    // Place the move
    _cells[row, col] = value;
    return true; // Move successful
}
```

**The Turn Cycle Complete!** 🔄

---

## Key Connections & Flow Summary

| Component | Responsibility | Connected To |
|-----------|-----------------|--------------|
| **Program.cs** | Entry point | Launches StartForm |
| **StartForm** | Game setup | Takes input, creates GameForm |
| **GameForm** | UI & orchestration | Displays board, calls GameState |
| **GameState** | Game rules | Validates moves, switches turns |
| **Board** | Data storage | Stores cell values |
| **Enums** | Data types | Used throughout all layers |

---

## Why This Architecture?

✅ **Separation of Concerns**
- Models handle logic independently
- Forms handle UI independently
- Easy to test each layer separately

✅ **Reusability**
- GameState could work with AI, network, or web UI
- Board logic is separate from display

✅ **Maintainability**
- Change UI without touching game logic
- Change game rules without touching UI
- Easy to add features (Sprint 3, 4, etc.)

✅ **Testability**
- Unit tests can test GameState & Board without UI
- Don't need to click buttons to test logic

---

**This is a classic MVC (Model-View-Controller) pattern adapted for Windows Forms!** 🎯
