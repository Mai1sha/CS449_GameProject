# SOS Game - Step-by-Step Execution Guide

## Table of Contents
1. [From Start Button Click to Game Board Display](#from-start-button-click-to-game-board-display)
2. [UI to Code Connection](#ui-to-code-connection)
3. [Memory & Object State](#memory--object-state)
4. [Playing a Complete Game Move](#playing-a-complete-game-move)

---

## From Start Button Click to Game Board Display

### **The User's Actions**

```
1. User opens app
2. User enters: "8" in board size field
3. User selects: "Simple" mode
4. User clicks: "Start" button
```

---

## Step-by-Step Code Execution

### **Step 1: Application Starts (Program.cs)**

**Code:**
```csharp
// This runs FIRST when you open the app
static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new StartForm());  // ← Creates StartForm window
    }
}
```

**What Happens:**
- The app launches
- Creates the **StartForm** object
- Shows it on screen
- Waits for user input

**Screen Output:**
```
┌─────────────────────────────┐
│  SOS Game Setup             │
├─────────────────────────────┤
│  Board Size: [_____]        │  ← User types "8" here
│  Game Mode:                 │
│  ◉ Simple  ○ General        │  ← User selects "Simple"
│  [ Start ]                  │  ← User clicks here
└─────────────────────────────┘
```

---

### **Step 2: User Enters "8" and Selects Game Mode**

**Code (In UI):**
```csharp
// In StartForm.Designer.cs (auto-generated)
this.BoardSizeTextBox.Text = "8";           // User types this
this.simpleGameButton.Checked = true;       // User selects this
```

**What Happens:**
- No code in your logic runs yet
- Just UI state change
- Values stored in form controls

---

### **Step 3: User Clicks "Start" Button** ⭐ **THIS IS WHERE THE MAGIC HAPPENS**

**Code:**
```csharp
// StartForm.cs
private void startGameButton_Click(object sender, EventArgs e)
{
    // Step 3a: Get the board size from the text box
    string boardSizeText = BoardSizeTextBox.Text;
    // boardSizeText = "8"
    
    // Step 3b: Try to convert to integer
    if (!TryGetBoardSize(out int boardSize))
    {
        MessageBox.Show("Please enter a valid board size (must be >= 3)");
        return;  // Stop here if invalid
    }
    // boardSize = 8 (now it's a number, not text)
    
    // Step 3c: Validate minimum size (already checked in TryGetBoardSize)
    // if (boardSize < 3) return false;  // This is inside TryGetBoardSize
    
    // Step 3d: Determine which game mode was selected
    GameMode selectedMode = generalGameButton.Checked 
        ? GameMode.General 
        : GameMode.Simple;
    // selectedMode = GameMode.Simple
    
    // Step 3e: CREATE THE GAMEFORM (Most important!)
    _gameForm = new GameForm(boardSize, selectedMode);
    //          ↓↓↓ THIS CALLS GameForm's Constructor ↓↓↓
    
    // Step 3f: Wire up the form closed event
    _gameForm.FormClosed += GameForm_FormClosed;
    
    // Step 3g: Show the game form
    _gameForm.Show();
    // The GameForm window appears on screen
    
    // Step 3h: Hide the start form
    this.Hide();
    // StartForm disappears
}

private bool TryGetBoardSize(out int boardSize)
{
    boardSize = 0;
    string input = BoardSizeTextBox.Text.Trim();

    if (string.IsNullOrEmpty(input))
        return false;

    if (!int.TryParse(input, out int size))
        return false;

    if (size < 3)
        return false;

    boardSize = size;
    return true;
}

private GameMode GetSelectedGameMode()
{
    return generalGameButton.Checked ? GameMode.General : GameMode.Simple;
}
```

**At this point:**
- `boardSize = 8`
- `selectedMode = GameMode.Simple`
- A new **GameForm** object is being created with those values
- **GameForm's constructor is about to execute!**

---

### **Step 4: GameForm Constructor Runs** 🔥 **THE REAL ACTION STARTS HERE**

**Code:**
```csharp
// GameForm.cs - Constructor
public GameForm(int boardSize, GameMode gameMode)
{
    // Step 4a: Initialize Windows Forms components
    InitializeComponent();
    // This creates all buttons, labels, etc. from Designer
    // Essentially unpacks the Designer.cs file
    
    // Step 4b: Create the GameState (The Brain!)
    _gameState = new GameState(boardSize, gameMode);
    // Parameters:
    //   boardSize = 8
    //   gameMode = GameMode.Simple
    // ↓↓↓ THIS CALLS GameState's Constructor ↓↓↓
    
    // Step 4c: Create array to hold button references
    _gridButtons = new Button[boardSize, boardSize];
    // Creates array to hold references to 64 buttons
    
    // Step 4d: Set the window title
    this.Text = $"SOS Game - {gameMode} ({boardSize}x{boardSize})";
    // Window title becomes: "SOS Game - Simple (8x8)"
    
    // Step 4e: Wire up event handlers
    WireUpEventHandlers();
    
    // Step 4f: Initialize the board display (draws the grid!)
    InitializeBoard();
    // ↓↓↓ DRAWS THE GRID ON SCREEN ↓↓↓
    
    // Step 4g: Set initial turn indicator
    UpdateUI();
    // Shows "Blue's Turn" on screen
}

private void WireUpEventHandlers()
{
    btnPlaceS.Click += btnPlaceS_Click;
    btnPlaceO.Click += btnPlaceO_Click;
    btnNewGame.Click += btnNewGame_Click;
}
```

**At this point:**
- GameForm constructor has started
- It's about to create GameState
- Which will create the Board

---

### **Step 5: GameState Constructor Creates the Board**

**Code:**
```csharp
// GameState.cs - Constructor
public GameState(int boardSize, GameMode gameMode = GameMode.Simple)
{
    // Step 5a: CREATE THE BOARD OBJECT (The Data Storage!)
    _board = new Board(boardSize);
    // boardSize = 8
    // ↓↓↓ THIS CALLS Board's Constructor ↓↓↓
    
    // Step 5b: Store the game mode
    _gameMode = gameMode;
    // _gameMode = GameMode.Simple
    
    // Step 5c: Set first player
    _currentPlayer = Player.Blue;
    // Blue always goes first!
    
    Console.WriteLine($"GameState created: {boardSize}x{boardSize} board");
}
```

**At this point:**
- GameState constructor has started
- It's about to create Board
- Board will initialize the 8×8 grid

---

### **Step 6: Board Constructor Creates the Game Grid**

**Code:**
```csharp
// Board.cs - Constructor
public Board(int size)
{
    // Step 6a: Validate size
    if (size < 3)
    {
        throw new ArgumentException("Board size must be at least 3", nameof(size));
    }
    // Validation passed! size = 8 ✓
    
    // Step 6b: Store the size
    _size = size;
    // _size = 8
    
    // Step 6c: CREATE THE ACTUAL GRID (2D array)
    _cells = new CellValue[size, size];
    // Creates an 8×8 array like this:
    // Row 0: [0,0] [0,1] [0,2] [0,3] [0,4] [0,5] [0,6] [0,7]
    // Row 1: [1,0] [1,1] [1,2] [1,3] [1,4] [1,5] [1,6] [1,7]
    // ...
    // Row 7: [7,0] [7,1] [7,2] [7,3] [7,4] [7,5] [7,6] [7,7]
    
    // Step 6d: Fill all cells with "Empty"
    for (int row = 0; row < size; row++)
    {
        for (int col = 0; col < size; col++)
        {
            _cells[row, col] = CellValue.Empty;
            // Every single cell is set to Empty
        }
    }
    
    Console.WriteLine($"Board created: {size}x{size} grid initialized");
}
```

**What the grid looks like now:**
```
_cells[,] array after initialization:

[ ][ ][ ][ ][ ][ ][ ][ ]   Row 0
[ ][ ][ ][ ][ ][ ][ ][ ]   Row 1
[ ][ ][ ][ ][ ][ ][ ][ ]   Row 2
[ ][ ][ ][ ][ ][ ][ ][ ]   Row 3
[ ][ ][ ][ ][ ][ ][ ][ ]   Row 4
[ ][ ][ ][ ][ ][ ][ ][ ]   Row 5
[ ][ ][ ][ ][ ][ ][ ][ ]   Row 6
[ ][ ][ ][ ][ ][ ][ ][ ]   Row 7

All 64 cells initialized to CellValue.Empty
```

**Constructor chain completes!** ✓

---

### **Step 7: Back to GameForm - InitializeBoard() Draws the Grid**

Now we're back in the GameForm constructor, at the `InitializeBoard()` call:

**Code:**
```csharp
// GameForm.cs
private void InitializeBoard()
{
    int boardSize = _gameState.Board.Size;
    // boardSize = 8
    
    int boardWidth = CalculateBoardDimension(boardSize);
    int boardHeight = CalculateBoardDimension(boardSize);
    // boardWidth = 8 * 50 + (8+1) * 10 = 400 + 90 = 490
    // boardHeight = 490

    ResizeForm(boardWidth, boardHeight);
    // Resizes the window to fit the board
    
    ConfigureGamePanel(boardWidth, boardHeight);
    // Sets up the panel that will hold the buttons
    
    PositionControlButtons(boardHeight);
    // Positions the "Place S", "Place O", "New Game" buttons
    
    CreateGridButtons(boardSize);
    // ↓↓↓ Creates all 64 buttons ↓↓↓
}

private int CalculateBoardDimension(int boardSize)
{
    return boardSize * CellSize + (boardSize + 1) * CellMargin;
    // = 8 * 50 + 9 * 10
    // = 400 + 90 = 490 pixels
}

private void CreateGridButtons(int boardSize)
{
    for (int row = 0; row < boardSize; row++)
    {
        for (int col = 0; col < boardSize; col++)
        {
            // Create ONE button for this cell
            CreateCellButton(row, col);
        }
    }
    // After loop: 8×8 = 64 buttons created!
}

private void CreateCellButton(int row, int col)
{
    Button button = new Button
    {
        Width = CellSize,                    // 50 pixels wide
        Height = CellSize,                   // 50 pixels tall
        Left = CellMargin + col * (CellSize + CellMargin),
        Top = CellMargin + row * (CellSize + CellMargin),
        Font = new Font("Arial", 16, FontStyle.Bold),
        Tag = (row, col)
    };

    // When button is clicked, call CellButton_Click with row and col
    button.Click += (s, e) => CellButton_Click(row, col);
    
    // Add button to the form
    panelGameBoard.Controls.Add(button);
    
    // Store reference for later
    _gridButtons[row, col] = button;
    
    // Example for cell [3,4]:
    // Left = 10 + 4 * (50 + 10) = 10 + 240 = 250
    // Top = 10 + 3 * (50 + 10) = 10 + 180 = 190
    // Button appears at position (250, 190) on screen
}
```

**Visual Result on Screen:**
```
┌─────────────────────────────────────────────────────┐
│  SOS Game - Simple (8x8)                            │
├─────────────────────────────────────────────────────┤
│  [ ][ ][ ][ ][ ][ ][ ][ ]                           │
│  [ ][ ][ ][ ][ ][ ][ ][ ]                           │
│  [ ][ ][ ][ ][ ][ ][ ][ ]                           │
│  [ ][ ][ ][ ][ ][ ][ ][ ]                           │
│  [ ][ ][ ][ ][ ][ ][ ][ ]                           │
│  [ ][ ][ ][ ][ ][ ][ ][ ]                           │
│  [ ][ ][ ][ ][ ][ ][ ][ ]                           │
│  [ ][ ][ ][ ][ ][ ][ ][ ]                           │
│                                                      │
│  Current Turn: Blue                                 │
│                                                      │
│  [Place S (Blue)]  [Place O (Red's turn)]           │
│  [New Game]                                         │
└─────────────────────────────────────────────────────┘
```

Each cell `[ ]` is a clickable Button!

---

### **Step 8: UpdateUI() Updates Turn Indicator**

**Code:**
```csharp
// GameForm.cs
private void UpdateUI()
{
    bool isBluePlayer = _gameState.CurrentPlayer == Player.Blue;
    // isBluePlayer = true (Blue is first)
    
    lblTurn.Text = $"Current turn: {_gameState.CurrentPlayer}";
    // lblTurn.Text = "Current turn: Blue"
    
    lblTurn.ForeColor = isBluePlayer ? Color.Blue : Color.Red;
    // lblTurn.ForeColor = Color.Blue
    
    UpdateButtonStates(isBluePlayer);
}

private void UpdateButtonStates(bool isBluePlayer)
{
    if (isBluePlayer)
    {
        // Blue's turn
        btnPlaceS.Enabled = true;
        btnPlaceS.BackColor = Color.LightBlue;
        btnPlaceS.Text = "Place S\n(Blue)";
        
        btnPlaceO.Enabled = false;
        btnPlaceO.BackColor = Color.LightGray;
        btnPlaceO.Text = "Place O\n(Red's turn)";
    }
    else
    {
        // Red's turn
        btnPlaceS.Enabled = false;
        btnPlaceS.BackColor = Color.LightGray;
        btnPlaceS.Text = "Place S\n(Blue's turn)";
        
        btnPlaceO.Enabled = true;
        btnPlaceO.BackColor = Color.LightCoral;
        btnPlaceO.Text = "Place O\n(Red)";
    }
}
```

**Final Screen:**
```
┌─────────────────────────────────────────────────────┐
│  SOS Game - Simple (8x8)                            │
├─────────────────────────────────────────────────────┤
│  [ ][ ][ ][ ][ ][ ][ ][ ]                           │
│  [ ][ ][ ][ ][ ][ ][ ][ ]                           │
│  [ ][ ][ ][ ][ ][ ][ ][ ]                           │
│  [ ][ ][ ][ ][ ][ ][ ][ ]                           │
│  [ ][ ][ ][ ][ ][ ][ ][ ]                           │
│  [ ][ ][ ][ ][ ][ ][ ][ ]                           │
│  [ ][ ][ ][ ][ ][ ][ ][ ]                           │
│  [ ][ ][ ][ ][ ][ ][ ][ ]                           │
│                                                      │
│  Current turn: Blue (← text in BLUE color)          │
│                                                      │
│  [Place S (Blue)] [Place O (Red's turn)]            │
│   ← Light Blue    ← Light Gray (disabled)           │
│  [New Game]                                         │
└─────────────────────────────────────────────────────┘
```

---

## Complete Constructor Chain Summary 📊

```
User clicks "Start"
    ↓
btnStart_Click() in StartForm
    ├─ Parse and validate input
    ├─ Get game mode
    └─ new GameForm(8, GameMode.Simple)
       ↓
       GameForm Constructor executes:
       ├─ InitializeComponent()
       │  └─ Unpacks Designer.cs, creates UI controls
       │
       ├─ new GameState(8, GameMode.Simple)
       │  ↓
       │  GameState Constructor executes:
       │  ├─ new Board(8)
       │  │  ↓
       │  │  Board Constructor executes:
       │  │  ├─ Validate size
       │  │  ├─ _cells = new CellValue[8,8]
       │  │  └─ Fill all 64 cells with Empty
       │  │     ↓ RETURN to GameState
       │  │
       │  ├─ _gameMode = GameMode.Simple
       │  ├─ _currentPlayer = Player.Blue
       │  └─ RETURN to GameForm
       │
       ├─ _gridButtons = new Button[8,8]
       │
       ├─ WireUpEventHandlers()
       │
       ├─ InitializeBoard()
       │  └─ Loop creates 64 buttons
       │     └─ Each positioned and added to form
       │        └─ Each has click event handler
       │
       ├─ UpdateUI()
       │  └─ Shows "Blue's Turn"
       │  └─ Enables/disables buttons
       │
       └─ RETURN to StartForm
    ↓
gameForm.Show()
    ↓
GameForm window appears on screen
    ↓
this.Hide() (StartForm disappears)
    ↓
GAME READY FOR PLAY! ✓
```

---

## UI to Code Connection

### How User Input Becomes Code Execution

```
USER ACTION                          CODE EXECUTION
════════════════════════════════════════════════════════════════

User opens app
    ↓
                                     Program.cs:
                                     Application.Run(new StartForm())
    ↓
User sees StartForm screen
    ↓
User types "8"
    ↓                                BoardSizeTextBox.Text = "8"
                                     (No code runs yet)
    ↓
User selects "Simple"
    ↓                                simpleGameButton.Checked = true
                                     (No code runs yet)
    ↓
User clicks "Start" button
    ↓
                                     startGameButton_Click()
                                     {
                                       Parse "8" to int → 8
                                       Get GameMode → Simple
                                       new GameForm(8, Simple)
                                     }
    ↓
                                     GameForm Constructor
                                     {
                                       new GameState(8, Simple)
                                       {
                                         new Board(8)
                                         {
                                           _cells[8,8] = Empty
                                         }
                                       }
                                       InitializeBoard()
                                       {
                                         Create 64 buttons
                                       }
                                       UpdateUI()
                                     }
    ↓
GameForm window appears on screen
```

---

## Memory & Object State

### Memory State After Construction

```csharp
// In memory, you have these objects:

StartForm object (hidden)
├─ BoardSizeTextBox: "8"
└─ simpleGameButton: checked = true

GameForm object (visible on screen)
├─ _gameState: GameState object
│  ├─ _board: Board object
│  │  ├─ _size: 8
│  │  └─ _cells: CellValue[8,8]
│  │     └─ All 64 cells = CellValue.Empty
│  │        Memory looks like:
│  │        [ ][ ][ ][ ][ ][ ][ ][ ]
│  │        [ ][ ][ ][ ][ ][ ][ ][ ]
│  │        ... (8 rows total)
│  │
│  ├─ _gameMode: GameMode.Simple
│  └─ _currentPlayer: Player.Blue
│
├─ _gridButtons: Button[8,8]
│  └─ 64 button references
│     Each button positioned on screen
│     Each has click handler attached
│
├─ btnPlaceS: Button (enabled, light blue)
├─ btnPlaceO: Button (disabled, light gray)
├─ btnNewGame: Button
└─ lblTurn: Label ("Current turn: Blue")
```

### Shared References

```
GameForm._gameState ─────→ GameState object
                          ├─ ._board ──→ Board object
                          │              ├─ ._cells ──→ CellValue[8,8] array
                          │              └─ ._size ──→ 8
                          ├─ ._gameMode ──→ GameMode.Simple
                          └─ ._currentPlayer ──→ Player.Blue
```

---

## Playing a Complete Game Move

### User Clicks Cell [3, 4]

**Code:**
```csharp
// GameForm.cs
// When user clicks button at row 3, col 4:

private void CellButton_Click(int row, int col)
{
    // row = 3, col = 4
    ClearPreviousSelection();
    HighlightSelectedCell(row, col);
}

private void ClearPreviousSelection()
{
    for (int r = 0; r < _gameState.Board.Size; r++)
    {
        for (int c = 0; c < _gameState.Board.Size; c++)
        {
            if (_gridButtons[r, c].BackColor == Color.Yellow)
                _gridButtons[r, c].BackColor = SystemColors.Control;
        }
    }
}

private void HighlightSelectedCell(int row, int col)
{
    _gridButtons[row, col].BackColor = Color.Yellow;
}
```

**Screen Output:**
```
[ ][ ][ ][ ][ ][ ][ ][ ]
[ ][ ][ ][ ][ ][ ][ ][ ]
[ ][ ][ ][ ][ ][ ][ ][ ]
[ ][ ][ ][🟨][ ][ ][ ][ ]  ← Cell [3,4] is now yellow
[ ][ ][ ][ ][ ][ ][ ][ ]
[ ][ ][ ][ ][ ][ ][ ][ ]
[ ][ ][ ][ ][ ][ ][ ][ ]
[ ][ ][ ][ ][ ][ ][ ][ ]
```

---

### User Clicks "Place S" Button

**Code:**
```csharp
// GameForm.cs
private void btnPlaceS_Click(object? sender, EventArgs e)
{
    PlaceMove('S');
}

private void PlaceMove(char value)
{
    // value = 'S'
    
    // Find the selected cell
    (int row, int col)? selectedCell = FindSelectedCell();

    if (!selectedCell.HasValue)
    {
        ShowMessage("Please select a cell first!", "No Cell Selected");
        return;
    }
    // selectedCell = (3, 4)

    TryPlaceMoveOnCell(selectedCell.Value.row, selectedCell.Value.col, value);
}

private (int row, int col)? FindSelectedCell()
{
    for (int row = 0; row < _gameState.Board.Size; row++)
    {
        for (int col = 0; col < _gameState.Board.Size; col++)
        {
            if (_gridButtons[row, col].BackColor == Color.Yellow)
                return (row, col);
        }
    }
    return null;
}

private void TryPlaceMoveOnCell(int row, int col, char value)
{
    // row = 3, col = 4, value = 'S'
    
    // Convert char to CellValue
    CellValue cellValue = value == 'S' ? CellValue.S : CellValue.O;
    // cellValue = CellValue.S
    
    // Call GameState to make the move
    bool moveSuccessful = _gameState.MakeMove(row, col, cellValue);
    // ↓↓↓ THIS CALLS GameState.MakeMove() ↓↓↓

    if (moveSuccessful)
    {
        UpdateCellDisplay(row, col, value);
        UpdateUI();
        // Updates to show Red's turn
    }
    else
    {
        ShowMessage("Cell already occupied!", "Invalid Move");
    }
}

private void UpdateCellDisplay(int row, int col, char value)
{
    _gridButtons[row, col].Text = value.ToString();  // "S"
    _gridButtons[row, col].BackColor = SystemColors.Control;
}
```

---

### GameState Processes the Move

**Code:**
```csharp
// GameState.cs
public bool MakeMove(int row, int col, CellValue cellValue)
{
    // row = 3, col = 4, cellValue = CellValue.S
    
    // Delegate to Board
    bool moveSuccessful = _board.PlaceMove(row, col, cellValue);
    // ↓↓↓ THIS CALLS Board.PlaceMove() ↓↓↓

    if (moveSuccessful)
    {
        SwitchPlayer();
        // Changes currentPlayer from Blue to Red
    }

    return moveSuccessful;
}

private void SwitchPlayer()
{
    _currentPlayer = _currentPlayer == Player.Blue ? Player.Red : Player.Blue;
    // _currentPlayer = Player.Red (was Blue)
}
```

---

### Board Executes the Move

**Code:**
```csharp
// Board.cs
public bool PlaceMove(int row, int col, CellValue value)
{
    // row = 3, col = 4, value = CellValue.S
    
    ValidateCoordinates(row, col);

    if (value == CellValue.Empty)
        throw new ArgumentException("Cannot place empty cell", nameof(value));

    // Check if cell is occupied
    if (_cells[row, col] != CellValue.Empty)
        return false; // Cell already occupied, move failed
    
    // _cells[3,4] is currently Empty, so continue

    // Place the move
    _cells[row, col] = value;
    // _cells[3,4] = CellValue.S ← The actual move!
    
    return true; // Move successful
}
```

**Board State After Move:**
```
_cells[,] array:

[ ][ ][ ][ ][ ][ ][ ][ ]   Row 0
[ ][ ][ ][ ][ ][ ][ ][ ]   Row 1
[ ][ ][ ][ ][ ][ ][ ][ ]   Row 2
[ ][ ][ ][S][ ][ ][ ][ ]   Row 3 ← Cell [3,4] now has S
[ ][ ][ ][ ][ ][ ][ ][ ]   Row 4
[ ][ ][ ][ ][ ][ ][ ][ ]   Row 5
[ ][ ][ ][ ][ ][ ][ ][ ]   Row 6
[ ][ ][ ][ ][ ][ ][ ][ ]   Row 7
```

---

### GameForm Updates Display

**Back to GameForm:**
```csharp
private void UpdateUI()
{
    // _gameState.CurrentPlayer is now Red (was changed in GameState)
    bool isBluePlayer = _gameState.CurrentPlayer == Player.Blue;
    // isBluePlayer = false (it's Red's turn now)
    
    lblTurn.Text = $"Current turn: {_gameState.CurrentPlayer}";
    // lblTurn.Text = "Current turn: Red"
    
    lblTurn.ForeColor = isBluePlayer ? Color.Blue : Color.Red;
    // lblTurn.ForeColor = Color.Red
    
    UpdateButtonStates(isBluePlayer);
}

private void UpdateButtonStates(bool isBluePlayer)
{
    // isBluePlayer = false
    
    // This is the ELSE branch:
    btnPlaceS.Enabled = false;
    btnPlaceS.BackColor = Color.LightGray;
    btnPlaceS.Text = "Place S\n(Blue's turn)";
    
    btnPlaceO.Enabled = true;
    btnPlaceO.BackColor = Color.LightCoral;
    btnPlaceO.Text = "Place O\n(Red)";
}
```

**Final Screen:**
```
┌─────────────────────────────────────────────────────┐
│  SOS Game - Simple (8x8)                            │
├─────────────────────────────────────────────────────┤
│  [ ][ ][ ][ ][ ][ ][ ][ ]                           │
│  [ ][ ][ ][ ][ ][ ][ ][ ]                           │
│  [ ][ ][ ][ ][ ][ ][ ][ ]                           │
│  [ ][ ][ ][S][ ][ ][ ][ ]  ← Blue's move appears   │
│  [ ][ ][ ][ ][ ][ ][ ][ ]                           │
│  [ ][ ][ ][ ][ ][ ][ ][ ]                           │
│  [ ][ ][ ][ ][ ][ ][ ][ ]                           │
│  [ ][ ][ ][ ][ ][ ][ ][ ]                           │
│                                                      │
│  Current turn: Red  (← text in RED color)           │
│                                                      │
│  [Place S (Blue's turn)] [Place O (Red)]            │
│   ← Light Gray (disabled)  ← Light Red (enabled)    │
│  [New Game]                                         │
└─────────────────────────────────────────────────────┘
```

---

### Turn Cycle Complete! 🔄

```
User clicked cell [3,4] and "Place S"
    ↓
GameForm.CellButton_Click(3, 4)
    ↓
GameForm.PlaceMove('S')
    ↓
GameForm.TryPlaceMoveOnCell(3, 4, 'S')
    ↓
GameState.MakeMove(3, 4, CellValue.S)
    ├─ Board.PlaceMove(3, 4, CellValue.S)
    │  └─ _cells[3,4] = CellValue.S ✓
    ├─ SwitchPlayer()
    │  └─ _currentPlayer = Red
    └─ return true
    ↓
GameForm.UpdateCellDisplay(3, 4, 'S')
    └─ _gridButtons[3,4].Text = "S"
    └─ _gridButtons[3,4].BackColor = white
    ↓
GameForm.UpdateUI()
    ├─ lblTurn.Text = "Red"
    ├─ lblTurn.ForeColor = Red
    ├─ btnPlaceS.Enabled = false
    └─ btnPlaceO.Enabled = true
    ↓
Screen shows Red's turn!
Red can now click cell and use "Place O"
```

---

**This is the complete flow from entering board size to playing a move!** 🎮
